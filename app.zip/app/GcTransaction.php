<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GcTransaction extends Model
{
    protected $table = 'gc_transactions';

}
