<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_transportation extends Model
{
    protected $table = 'gc_transportations';
    protected $guarded = [];
}
