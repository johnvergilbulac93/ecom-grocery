<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_picker extends Model
{
    protected $table = 'gc_pickers';
}
