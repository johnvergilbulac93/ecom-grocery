<template>
  <div><h1>EXPORT FILES</h1></div>
</template>
<script>
export default {
  name: "Export",
  created() {},
  data() {
    return {};
  },
  props: {},
  methods: {},
};
</script>
