<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_reprint_barcode extends Model
{
    //
}
