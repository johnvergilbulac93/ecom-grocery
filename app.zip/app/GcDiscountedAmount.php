<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GcDiscountedAmount extends Model
{

    protected $table = 'gc_discounted_amounts';
}
