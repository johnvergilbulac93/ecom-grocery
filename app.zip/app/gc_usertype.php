<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;


class gc_usertype extends Model
{
    protected $table = 'user_types';


}
