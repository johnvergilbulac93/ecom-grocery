<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GcPackageDetails extends Model
{
    protected $table = 'gc_package_details';
}
