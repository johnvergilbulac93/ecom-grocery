<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_employee extends Model
{
    protected $table = 'gc_employee3s';

}
