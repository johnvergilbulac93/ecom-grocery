<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GCFinalOrder extends Model
{

    protected $table = 'gc_final_order';
}
