<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_bunit_code extends Model
{
    protected $table = 'locate_business_units';

}
