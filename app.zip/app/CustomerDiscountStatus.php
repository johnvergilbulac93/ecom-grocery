<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerDiscountStatus extends Model
{
   protected $table = 'customer_discount_statuses';

}
