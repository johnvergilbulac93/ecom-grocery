<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gc_setup_business_rule extends Model
{
    //
}
