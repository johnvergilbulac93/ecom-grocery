<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerBill extends Model
{

    protected $table = 'customer_bills';
}
